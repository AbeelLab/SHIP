"""Finds regions with evidence of HGT between plasmids and groups plasmids according to evolutionary dynamics."""

__version__="0.2.3"

from ship_plasmid.ship import main